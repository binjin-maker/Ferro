FERRO  -  build 82
=================

RUN IT
  1. Rename  Ferro.ex_  to  Ferro.exe
  2. Double-click it. First start takes a few seconds while the island is generated.
  Saves (ferro.sav), screenshots and any crash note are written next to the exe.
  Windows may warn about an unknown publisher (More info > Run anyway); the exe is not
  code-signed, so Smart App Control has to be off.

THE CODE LOCK
  The first time the game runs on a computer it shows a code lock. Type or click the
  6-digit access code and press OK (ENTER). C clears, BACKSPACE takes one digit back.
  It only asks once per computer. A wrong code gives a jolt; three wrong codes and that
  copy of the game deletes itself.

UPDATES
  The title screen shows the build number and checks GitHub for a newer one. When there
  is one, press UPDATE: the game downloads it, checks its SHA-256 fingerprint, swaps
  itself and restarts. Saves and settings stay where they are.
  Home of the game: github.com/binjin-maker/Ferro

CONTROLS
  WASD move        SHIFT sprint       CTRL / C crouch     SPACE jump
  LMB use / hit / fire                RMB aim, or hold for the piece / upgrade wheel
  E use, open, pick up, get in        R reload, rotate what you are placing
  1-6 or mouse wheel: belt            TAB inventory        Q crafting        M map
  BACKSPACE drop what is in your hand (in a menu: the stack under the pointer)
  hold R: ammo menu                   N night vision (needs goggles)      T, ENTER or / chat and commands
  F3 fps    F5 quick save    F11 fullscreen    F12 screenshot    ESC menu

INVENTORY
  Drag to move. Middle-click splits a stack. SHIFT+click (or right-click) sends a stack
  to the other inventory; each kind of item takes a moment to hand over.

TOOLS
  Rock, hatchets and pickaxes are two-handed. A swing only bites if something is in
  reach (about a metre and a half; the spear reaches further) - miss and it swings
  through air. Ore nodes show a glinting weak spot: hit it for extra yield.
  JACKHAMMER: hold LMB and lean on a node. It finds the weak spot by itself.
  150 scrap at the outpost General Store, or craft it at a level 2 workbench.

OUTPOST  (safe zone: weapons stay down, the guards leave you alone)
  West side, three bays: General Store, Weapons Dealer, and in the last bay two machines:
  RESOURCE EXCHANGE (scrap buys wood, stone, metal...) and SCRAP EXCHANGE (bring wood,
  stone, metal, sulfur, cloth, fuel or leather and it pays scrap).
  East side, under the lean-to: a level 1 WORKBENCH, a repair bench, a research table.
  RESEARCH TABLE: press E and you get a board of every blueprint you don't know yet, each
  with its price in scrap. Click one, the scrap comes out of your pockets, it's learned.
  Middle of the yard: the recycler. Back of the yard: the helipad and the Air Wolf booth.

HELICOPTERS  (bought with scrap at the helipad)
  E get in / out       W / S lift          A / D turn
  Mouse or arrow keys tilt             X level out          ALT look around
  Attack helicopter: LMB nose gun, RMB rockets (both fed from its cargo hatch)
  Fuel goes in the hatch on the side (low grade fuel).

OUT IN THE WORLD
  Junk piles and wrecks along every road and scattered through the country: barrels to
  break open, a crate here and there. Military crates are guarded - the mining outpost,
  the satellite dish and the broadcast tower all have scientists now.

MUSIC
  Plays by itself: ambient while it is quiet, hard techno or rock when a fight starts.

BUILDING
  Hold the BUILDING PLAN. Right-click and hold for the wheel of pieces: foundation, steps,
  wall, half wall, low wall, doorway, window, floor, stairs, roof. Stand close (about four
  metres) and look at where the piece should go: a see-through blue ghost snaps to the
  nearest free spot - a foundation edge for walls, the top of walls for floors, the side of
  a foundation for more foundations or steps. Red ghost = it can't go there, and the
  reason is written under the crosshair. Left-click builds it in twig; R turns stairs and
  roofs. The first foundation of a base goes on any reasonably flat ground.
  Hold the HAMMER and look at a piece to see its material, health and STABILITY. Left-click
  repairs. Right-click and hold: upgrade to wood, stone, sheet metal or armoured, demolish,
  or rotate (stairs and roofs).
  Stability: foundations are solid ground, walls lose a little each storey, floors lose a
  lot for every cell they reach out from a wall (three cells is the limit). Knock out what
  holds a piece up and it comes down.

NEW IN THIS BUILD
  Cars on the roads: five engine parts and low grade under the hood, real suspension, they can
  roll over, and stay over. New flesh-hit and headshot sounds.
  (Build 61:)
  Island twice the size (old saves will not load). RENDER SCALE and SHADOWS in OPTIONS for speed.
  Guns work in the Outpost; only hitting someone or breaking something there starts a fight.
  (Build 59:)
  Fishing Port on the shore, with a dinghy for 125 scrap (W/S/A/D, mouse to look, E in and out).
  (Build 58:)
  Smoother in forest and at the Outpost. Headshots. The Outpost can be raided. Water splashes.
  Scientists no longer walk on air or water. Workbench level speeds up crafting.
  (Build 57:)
  Flashlight, headlamp (eyes slot, N), Jacket (suit slot). Rock collision fixed. Hold R to unload.
  /loadout, /loadoutclear, /mini, /undev. Heavy plate set reaches 90%.
  (Build 35:)
  Loading a save made in a helicopter no longer drops you out of the sky.
  (Build 37:)
  Attack helicopter cockpit cleaned up. ALT look uses your sensitivity.
  (Build 36:)
  Attack helicopter shots land on the crosshair.
  (Build 35:)
  Chainsaw sound, sweep and running chain. Large Oil Rig has a vault platform. Attack helicopter
  aims at the crosshair and takes explosive 5.56. Boss helicopter harder. Better survivor models.
  Wood, stone and metal trade for more scrap.
  (Build 34:)
  Survivors and traders look like people: clothes, hat, backpack.
  (Build 33:)
  Chainsaw. CHECK FOR UPDATES button on the main menu. Upkeep notice updates quickly.
  (Build 32:)
  Heavy plate beats metal plate. Combat music lasts until you leave the fight or 2:30 of quiet.
  (Build 31:)
  Settings are remembered. Separate music and effects volume. Survivors roam the island;
  peaceful ones trade at the Outpost (E). Turret lock-on warning. Distinct item icons.
  (Build 30:)
  Hands grip the magazine and rack the handle during reloads. Runs faster at busy places.
  (Build 29:)
  Blank icons fixed. Hotbar shows the loaded round. Eoka reloads and can be repaired.
  Explosive rounds burst visibly; dropped crates last five minutes. Jetpack removed.
  (Build 28:)
  Thermal goggles are the cheap ones (50 m); the tracking headset costs more and reaches 45 m.
  (Build 26:)
  Heavy plate armour, a Plate Suit worn over clothes, combat boots, large backpack.
  Explosive 5.56 (B switches ammo type, then R). Helicopter rockets toned down.
  (Build 24:)
  Helicopter rockets: less damage, smaller blast, much less accurate.
  (Build 24:)
  Turrets remodelled: tripod, yoke, gun and camera eye.
  (Build 23:)
  Industrial turrets. The Arms Depot is harder and has a Vault behind a door that takes
  three C4.
  (Build 22:)
  Arms Depot and Large Oil Rig: harder raids. Shot-down gunships crash. Space jumps you
  out of the water.
  (Build 21:)
  Satchel charges and C4: left-click to plant, then run. One C4 (or four satchels) opens
  a blast door.
  (Build 20:)
  No more radio or boom box: ambient music plays by itself and turns to hard techno or rock
  when a fight starts.
  (Build 19:)
  THE RAID UPDATE: an oil rig at sea and a bunker on land, held by heavy scientists and
  turrets. Locked crates take 50 s to open and call in a gunship (and a gunboat at the rig).
  The bunker's blast door only opens to explosives. A patrol helicopter roams now and then.
  Minicopter: F for a gun in hand, and you can aim it. Bullet damage falls off with range.
  (Build 18:)
  Third person removed.
  (Build 17:)
  Boots show on your feet.
  (Build 16:)
  Minicopter: F takes your hands off the stick so you can shoot; the craft holds its attitude.
  Calmer running animation, trigger finger moves, sky steady when turning.
  (Build 15:)
  Arctic, Tactical and Scientist hazmat suits.
  FEET slot with shoes and boots. Usable sights and a real scope on the bolt action.
  Real bullet spread. Map pins and helicopters on the compass.
  Scientists steer round walls and come for where they were shot from.
  (Build 14:)
  Scientists: less health, less damage, worse aim, shorter sight; they no longer walk through things.
  (Build 13:)
  Outpost sentry turrets: shoot a scientist there and they lock on to you for 5 minutes.
  Destructible auto turrets guard the tower, dish and warehouse.
  (Build 12:)
  New guns: Python Revolver, M92 Pistol, LR-300, M249, Rocket Launcher (uses rockets).
  Reloads: magazines really come out and go back in.
  (Build 11:)
  Every gun has its own sound. No shooting while sprinting.
  Scientists: more of them everywhere, they call each other, sidestep and hunt for you.
  General Exchange (outpost scrap exchange): sell anything you carry for a little scrap.
  MAIN MENU in the pause menu. Trees no longer block helicopters above their tops.
  (Builds 8-10:)
  Half-looted crates respawn after 15 minutes (emptied ones after 10).
  (Build 9:)
  Attack helicopter gun fires again. Scientists shoot at helicopters within about 110 m.
  (Build 8:)
  Tools: fists roll round the handle with the swing, so wrists no longer flip at the ends.
  Rock: new one-handed overhand smash.
  Backpack: 50 cloth + 10 leather, worn in the new BACK slot, 12 more inventory slots.
  Semi, SMG and rifle bodies are craftable (Components tab). Handmade shells: 5 per craft
  from gunpowder, metal fragments and stone.
  Revolver and Custom SMG also take handmade shells; waterpipe, double barrel and
  blunderbuss also take pistol bullets.
  4 second wait on the death screen before you can respawn.
  Gas station pumps break open for low grade fuel, metal fragments and scrap.
  Helicopters cost less: Minicopter 500, Transport 850, Attack 1500. The attack
  helicopter has an inside.

STILL TO COME
  Smarter and better-looking scientists with keycard rooms, the rest of the art pass on
  tools and weapons, and a stone spear you can throw.

CREDITS AND LICENCES
  Written in Rust with macroquad / miniquad (MIT or Apache-2.0), cpal (Apache-2.0),
  serde (MIT or Apache-2.0), bincode (MIT), ureq (MIT or Apache-2.0), rustls and ring
  (Apache-2.0 / ISC / MIT), sha2 (MIT or Apache-2.0) and self-replace (Apache-2.0).
  Hand model based on the WebXR Input Profiles generic hand asset, MIT licence,
  Copyright (c) 2019 Amazon.com, Inc. or its affiliates.
  Fonts: Roboto Condensed (Apache-2.0, Google) and Permanent Marker (Apache-2.0, Font Diner).
  Everything else (world, models, textures, sounds, music) is generated by the game's own code.
  This is a fan-made hobby project and is not affiliated with Facepunch Studios.
