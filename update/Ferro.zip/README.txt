FERRO  -  build 7
=================

RUN IT
  1. Rename  Ferro.ex_  to  Ferro.exe
  2. Double-click it. First start takes a few seconds while the island is generated.
  Saves (ferro.sav), screenshots and any crash note are written next to the exe.
  Windows may warn about an unknown publisher (More info > Run anyway); the exe is not
  code-signed, so Smart App Control has to be off.

THE CODE LOCK
  The first time the game runs on a computer it shows a code lock. Type or click the
  6-digit access code and press OK (ENTER). C clears, BACKSPACE takes one digit back.
  It only asks once per computer. A wrong code gives a jolt; three wrong codes and that
  copy of the game deletes itself.

UPDATES
  The title screen shows the build number and checks GitHub for a newer one. When there
  is one, press UPDATE: the game downloads it, checks its SHA-256 fingerprint, swaps
  itself and restarts. Saves and settings stay where they are.
  Home of the game: github.com/binjin-maker/Ferro

CONTROLS
  WASD move        SHIFT sprint       CTRL / C crouch     SPACE jump
  LMB use / hit / fire                RMB aim, or hold for the piece / upgrade wheel
  E use, open, pick up, get in        R reload, rotate what you are placing
  1-6 or mouse wheel: belt            TAB inventory        Q crafting        M map
  BACKSPACE drop what is in your hand (in a menu: the stack under the pointer)
  N night vision (needs goggles)      T, ENTER or / chat and commands
  F3 fps    F5 quick save    F11 fullscreen    F12 screenshot    ESC menu

INVENTORY
  Drag to move. Middle-click splits a stack. SHIFT+click (or right-click) sends a stack
  to the other inventory; each kind of item takes a moment to hand over.

TOOLS
  Rock, hatchets and pickaxes are two-handed. A swing only bites if something is in
  reach (about a metre and a half; the spear reaches further) - miss and it swings
  through air. Ore nodes show a glinting weak spot: hit it for extra yield.
  JACKHAMMER: hold LMB and lean on a node. It finds the weak spot by itself.
  150 scrap at the outpost General Store, or craft it at a level 2 workbench.

OUTPOST  (safe zone: weapons stay down, the guards leave you alone)
  West side, three bays: General Store, Weapons Dealer, and in the last bay two machines:
  RESOURCE EXCHANGE (scrap buys wood, stone, metal...) and SCRAP EXCHANGE (bring wood,
  stone, metal, sulfur, cloth, fuel or leather and it pays scrap).
  East side, under the lean-to: a level 1 WORKBENCH, a repair bench, a research table.
  RESEARCH TABLE: press E and you get a board of every blueprint you don't know yet, each
  with its price in scrap. Click one, the scrap comes out of your pockets, it's learned.
  Middle of the yard: the recycler. Back of the yard: the helipad and the Air Wolf booth.

HELICOPTERS  (bought with scrap at the helipad)
  E get in / out       W / S lift          A / D turn
  Mouse or arrow keys tilt             X level out          ALT look around
  Attack helicopter: LMB nose gun, RMB rockets (both fed from its cargo hatch)
  Fuel goes in the hatch on the side (low grade fuel).

OUT IN THE WORLD
  Junk piles and wrecks along every road and scattered through the country: barrels to
  break open, a crate here and there. Military crates are guarded - the mining outpost,
  the satellite dish and the broadcast tower all have scientists now.

RADIO
  Hold the handheld radio (or look at a boombox), LMB turns it on, mouse wheel tunes in
  0.05 MHz steps from 87.5 to 108. The closer you are to a station the less static.

BUILDING
  Hold the BUILDING PLAN. Right-click and hold for the wheel of pieces: foundation, steps,
  wall, half wall, low wall, doorway, window, floor, stairs, roof. Stand close (about four
  metres) and look at where the piece should go: a see-through blue ghost snaps to the
  nearest free spot - a foundation edge for walls, the top of walls for floors, the side of
  a foundation for more foundations or steps. Red ghost = it can't go there, and the
  reason is written under the crosshair. Left-click builds it in twig; R turns stairs and
  roofs. The first foundation of a base goes on any reasonably flat ground.
  Hold the HAMMER and look at a piece to see its material, health and STABILITY. Left-click
  repairs. Right-click and hold: upgrade to wood, stone, sheet metal or armoured, demolish,
  or rotate (stairs and roofs).
  Stability: foundations are solid ground, walls lose a little each storey, floors lose a
  lot for every cell they reach out from a wall (three cells is the limit). Knock out what
  holds a piece up and it comes down.

NEW IN THIS BUILD
  Bow: carried off to the right, and it comes to the middle as you pull back or aim.
  Research: no item needed any more. The table is a board of blueprints bought with scrap.
  Building: the plan works at arm's length with a see-through ghost that snaps to where
  you look and says why not when it can't; pieces land with dust and a knock. Twig is now a
  frame of sticks. New pieces: half wall, low wall, foundation steps. Every piece has a
  stability; the hammer shows it, and the wheel can rotate stairs and roofs.
  (Build 6: every sound rebuilt, written songs on the radio.)

STILL TO COME
  Smarter and better-looking scientists with keycard rooms, the rest of the art pass on
  tools and weapons, and a stone spear you can throw.

CREDITS AND LICENCES
  Written in Rust with macroquad / miniquad (MIT or Apache-2.0), cpal (Apache-2.0),
  serde (MIT or Apache-2.0), bincode (MIT), ureq (MIT or Apache-2.0), rustls and ring
  (Apache-2.0 / ISC / MIT), sha2 (MIT or Apache-2.0) and self-replace (Apache-2.0).
  Hand model based on the WebXR Input Profiles generic hand asset, MIT licence,
  Copyright (c) 2019 Amazon.com, Inc. or its affiliates.
  Fonts: Roboto Condensed (Apache-2.0, Google) and Permanent Marker (Apache-2.0, Font Diner).
  Everything else (world, models, textures, sounds, music) is generated by the game's own code.
  This is a fan-made hobby project and is not affiliated with Facepunch Studios.
